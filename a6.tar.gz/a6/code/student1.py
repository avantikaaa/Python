class Student:
	name = ""
	rollNumber = 0
	def __init__(self, name, rollNumber):
		self.rollNumber = rollNumber
		self.name = name
