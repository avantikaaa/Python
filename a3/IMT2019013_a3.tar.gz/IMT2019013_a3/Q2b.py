from Q2input import *

# Your code - begin
output = inp

# Your code - end
print output
