inp = "Plombez vingt fuyards!"

