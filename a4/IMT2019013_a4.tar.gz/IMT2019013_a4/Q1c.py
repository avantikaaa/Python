def print_n_messages(m):		#Function for printing "Hello World!" 10 times the given number
    i = 0
    while (i<m*10):
        print "Hello World!"
        i += 1

