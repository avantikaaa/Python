class MyMath:
	def add(self, a, b):		#Addition
		return a+b

	def subtract(self, a, b):	#Subtraction
		return a-b

	def multiply(self, a, b):	#Multiplication
		return a*b

	def divide(self, a, b):		#Division
		return a/b
