def print_n_messages():		#Function for printing "Hello World!" 10 times
    i = 0
    while(i<10):
        print "Hello World!"  
        i += 1

