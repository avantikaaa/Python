def print_n_messages(n):	#Function for printing "Hello World!" given number of times
    i = 0
    while(i<n):
        print "Hello World!"
        i += 1

