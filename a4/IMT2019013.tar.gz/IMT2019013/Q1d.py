def print_n_messages(m,n):		#Function for printing "Hello World!" m*n times (m,n are taken as inputs)
    i = 0
    while (i<m*n):
        print "Hello world!"
        i += 1

