def hello(name):
## Your code - begin
	return "Hello "+name		#OUTPUT: string -> "Hello *input*"
## Your code - end
  
if __name__ == "__main__":
  print hello("IIITB")
