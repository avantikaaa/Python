def print_n_messages(m,n):		#Function for printing the given message "m" n times
    i = 0
    while (i<n):
        print str(m)
        i += 1

